let display = document.querySelector(".display input");
let buttons = document.querySelectorAll(".buttons button");

// Add click event listener to all buttons
buttons.forEach(button => {
  button.addEventListener("click", function() {
    let value = button.textContent;

    // Handle number buttons
    if (!isNaN(value)) {
      display.value += value;
    }

    // Handle operator buttons
    if (value === "+" || value === "-" || value === "*" || value === "/") {
      let lastChar = display.value[display.value.length - 1];

      // Don't allow multiple operators in a row
      if (lastChar !== "+" && lastChar !== "-" && lastChar !== "*" && lastChar !== "/") {
        display.value += value;
      }
    }

    // Handle function buttons
    if (value === "sin" || value === "cos" || value === "tan" || value === "sqrt") {
      let result = 0;
      let operand = parseFloat(display.value);

      switch(value) {
        case "sin":
          result = Math.sin(operand);
          break;
        case "cos":
          result = Math.cos(operand);
          break;
        case "tan":
          result = Math.tan(operand);
          break;
        case "sqrt":
          result = Math.sqrt(operand);
          break;
      }

      display.value = result.toFixed(6);
    }

    // Handle clear button
    if (value === "C") {
      display.value = "";
    }

    // Handle equals button
    if (value === "=") {
      let result = eval(display.value);

      if (isNaN(result)) {
        display.value = "";
      } else {
        display.value = result.toFixed(6);
      }
    }
  });
});
